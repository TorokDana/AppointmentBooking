INFO: AZ ALÁBBI LISTA A FELADATKIÍRÁS AZ EGYETEM ÁLTAL, MIVEL A PROJEKT EGY BEADANDÓM VOLT. NINCS FELRAKVA INTERNETRE, KÉREM FUTTASSA LOCALHOSTBAN HA MEGTEKINTI. ADMIN BEJELENTKEZÉS: EMAIL: ADMIN@NEMKOVID.HU PWD:ADMIN





Minimálisan teljesítendő (6 pont)

[x] Listaoldal: megjelenik (0 pont)
[x] Listaoldal: statikus szöveg és tájékoztató (0 pont)
[x] Listaoldal: összes időpont listázása (1 pont)
[x] Admin: új időpont felvétele, hibakezelés (bejelentkezés és admin funkciók nélkül) (2 pont)
[x] Admin: új időpont felvétele, sikeres mentés (bejelentkezés és admin funkciók nélkül) (2 pont)

Az alap feladatok (14 pont)

[x] Listaoldal: Adott hónapba eső időpontok listázása (0,5 pont)
[x] Listaoldal: Előző és következő hónap listázása (1 pont)
[x] Listaoldal: Szabad időpont zöld, a betelt piros (0,5 pont)
[x] Listaoldal: Jelentkezés gomb megjelenik az időpontok mellett vendégnek (0,5 pont)
[x] Listaoldal: Jelentkezés gomb megjelenik az időpontok mellett bejelentkezés után, ha nincs foglalásunk (0,5 pont)
[x] Listaoldal: Jelentkezés gomb nem jelenik meg az időpontok mellett bejelentkezés után, ha már van foglalásunk (0,5 pont)
[x] Listaoldal: Jelentkezés gomb URL-je a megfelelő időpont részletező oldalára mutat (0,5 pont)
[x] Listaoldal: ha van már foglalásunk és be vagyunk jelentkezve, akkor a foglalás adatai megjelennek (1 pont)
[x] Listaoldal: ha van már foglalásunk és be vagyunk jelentkezve, akkor a foglalás lemondható (0,5 pont)
[x] Listaoldal: minden bejelentkezett felhasználó csak a saját foglalását mondhatja le (jogosultságvizsgálat) (0,5 pont)
[x] Regisztrációs űrlap: megfelelő elemeket tartalmaz (0,5 pont)
[x] Regisztrációs űrlap: hibás esetek kezelése, hibaüzenet, állapottartás (1,5 pont)
[x] Regisztrációs űrlap: sikeres regisztráció (0,5 pont)
[x] Bejelentkezés: hibás esetek kezelése (1 pont)
[x] Bejelentkezés: sikeres belépés (0,5 pont)
[x] Jelentkezés részletei: az időpont és felhasználó adatai rendben megjelennek (0,5 pont)
[x] Jelentkezés részletei: jelölőmező helyes kezelése (0,5 pont)
[x] Jelentkezés részletei: sikeres jelentkezés (1 pont)
[x] Admin: be lehet jelentkezni admin felhasználó adataival (0,5 pont)
[x] Admin: időpont részletei oldalon megjelennek az erre jelentkezett felhasználók adatai (0,5 pont)
[x] Admin: új időpont meghirdetése csak admin felhasználóval érhető el (0,5 pont)
[x] Nincs nagyobb programhiba, nem csalhatók elő furcsa jelenségek (0,5 pont)
[x] Igényes kialakítás (1 pont)

Plusz feladatok (plusz 5 pont)

[x] Listaoldal: időpontok naptár formátumban (2,5 pont)
[x] Listaoldal: AJAX naptár lapozás (1 pont)
[x] Bejelentkezés: megőrzi a kiválasztott időpontot (1 pont)
[x] Űrlapok: a regisztrációs és az új időpont űrlapon a hibaüzeneteket az űrlapmezők mellett jelennek meg (0,5 pont)