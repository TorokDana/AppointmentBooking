<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sikeres jelentkezés</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h1> Nemzeti Koronavírus Depó</h1>
<a class='asbutton' href="index.php">Vissza a főoldalra</a>
<a class='asbutton' href="login.php?ki='igen">Kijelentkezés</a>

<h2>A jelentkezés sikeres</h2>
<h3>Köszönjük hogy minket választott.</h3>
<small>Kérjük ne felejtse el magával hozni a szükséges iratait. Az esetlegesen fellésmallő mellékhatásokért felelősséget nem vállalunk. Az időponton megjelenni kötelező. Ha ön ezt bármi okból kifolyólag elmulasztja 300.000 Ft-tól 1 millió forintig terjedő pénzbírságra kötelezhető, illetve szabadságvesztéssel járhat. </p>
    
</body>

<footer><img style="height:198px" src="jobban.jpg" alt=""></footer>
</html>